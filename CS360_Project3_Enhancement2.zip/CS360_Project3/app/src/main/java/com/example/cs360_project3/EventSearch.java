package com.example.cs360_project3;

import java.util.Collections;
import java.util.List;

/**
 * Utility class that performs binary search on event names.
 * Demonstrates algorithm enhancement for the CS499 portfolio.
 */
public class EventSearch {

    /**
     * Sorts the list alphabetically before searching.
     *
     * @param events List of event names
     * @param target Event name to search for
     * @return index if found, otherwise -1
     */
    public static int binarySearch(List<String> events, String target) {

        if (events == null || target == null) {
            return -1;
        }

        Collections.sort(events, String.CASE_INSENSITIVE_ORDER);

        int low = 0;
        int high = events.size() - 1;

        while (low <= high) {

            int mid = (low + high) / 2;

            int comparison =
                    events.get(mid).compareToIgnoreCase(target);

            if (comparison == 0) {
                return mid;
            }

            if (comparison < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1;
    }
}