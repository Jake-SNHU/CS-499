package com.example.cs360_project3;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

/**
 * RecyclerView adapter responsible for displaying events
 * and handling edit/delete actions.
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    private final Context context;
    private Cursor cursor;
    private final DatabaseHelper db;

    /**
     * Constructor.
     *
     * @param context Activity context
     * @param cursor Database cursor
     * @param db Database helper
     */
    public EventAdapter(Context context, Cursor cursor, DatabaseHelper db) {

        this.context = context;
        this.cursor = cursor;
        this.db = db;
    }

    /**
     * Holds references to controls inside each RecyclerView row.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvName;
        TextView tvDate;

        Button btnEdit;
        Button btnDelete;
        TextView tvTime;
        TextView tvDescription;

        public ViewHolder(View view) {

            super(view);

            tvName = view.findViewById(R.id.tvEventName);
            tvDate = view.findViewById(R.id.tvEventDate);
            tvTime = view.findViewById(R.id.tvEventTime);
            tvDescription = view.findViewById(R.id.tvEventDescription);

            btnEdit = view.findViewById(R.id.btnEdit);
            btnDelete = view.findViewById(R.id.btnDelete);
        }
    }

    /**
     * Creates a new ViewHolder.
     */
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.event_item, parent, false);

        return new ViewHolder(view);
    }

    /**
     * Binds database data to each RecyclerView row.
     */
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        if (cursor == null || !cursor.moveToPosition(position)) {
            return;
        }

        int id = cursor.getInt(
                cursor.getColumnIndexOrThrow("eventId"));

        String name = cursor.getString(
                cursor.getColumnIndexOrThrow("name"));

        String date = cursor.getString(
                cursor.getColumnIndexOrThrow("date"));

        String time = cursor.getString(
                cursor.getColumnIndexOrThrow("time"));

        String description = cursor.getString(
                cursor.getColumnIndexOrThrow("description"));

        holder.tvName.setText(name);
        holder.tvDate.setText(date);
        holder.tvDate.setText("Date: " + date);
        holder.tvTime.setText("Time: " + time);
        holder.tvDescription.setText(description);

        /*
         * Loads the selected event into DashboardActivity
         * so the user can edit it.
         */
        holder.btnEdit.setOnClickListener(v -> {

            if (context instanceof DashboardActivity) {

                ((DashboardActivity) context).editEvent(
                        id,
                        name,
                        date,
                        time,
                        description
                );
            }
        });

        /*
         * Deletes the selected event and refreshes
         * the RecyclerView immediately.
         */
        holder.btnDelete.setOnClickListener(v -> {

            if (db.deleteEvent(id)) {

                swapCursor(db.getAllEvents("name"));

            }

        });
    }

    /**
     * Returns number of events.
     */
    @Override
    public int getItemCount() {

        return cursor == null ? 0 : cursor.getCount();
    }

    /**
     * Replaces the cursor and refreshes the RecyclerView.
     *
     * @param newCursor Updated cursor.
     */
    public void swapCursor(Cursor newCursor) {

        if (cursor != null && !cursor.isClosed()) {

            cursor.close();

        }

        cursor = newCursor;

        notifyDataSetChanged();
    }
}