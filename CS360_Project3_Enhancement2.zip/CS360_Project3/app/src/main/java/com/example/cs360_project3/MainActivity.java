package com.example.cs360_project3;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * Entry point for the Event Tracker application.
 *
 * This activity applies edge-to-edge display support and
 * immediately launches the LoginActivity so users can
 * authenticate before accessing the application.
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Initializes the application and redirects the user
     * to the login screen.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable edge-to-edge display for modern Android devices
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);

        // Apply padding to prevent overlap with system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main),
                (view, insets) -> {
                    Insets systemBars =
                            insets.getInsets(WindowInsetsCompat.Type.systemBars());

                    view.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                });

        // Launch the login screen
        startActivity(new Intent(this, LoginActivity.class));

        // Remove MainActivity from the back stack
        finish();
    }
}