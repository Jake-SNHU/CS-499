package com.example.cs360_project3;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Handles requesting SMS permission and sending
 * a reminder text message after permission is granted.
 */
public class PermissionActivity extends Activity {

    private static final int SMS_PERMISSION_CODE = 1;

    // Demo values used for the reminder message
    private static final String PHONE_NUMBER = "5551234567";
    private static final String MESSAGE = "Reminder: Upcoming event!";

    /**
     * Initializes the permission request screen.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Button btnGrant = findViewById(R.id.btnGrantPermission);

        btnGrant.setOnClickListener(v -> requestSmsPermission());
    }

    /**
     * Requests SMS permission if it has not already been granted.
     */
    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(this,
                    "SMS permission already granted.",
                    Toast.LENGTH_SHORT).show();

            sendReminderMessage();

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    /**
     * Handles the user's response to the permission request.
     */
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this,
                        "SMS permission granted.",
                        Toast.LENGTH_SHORT).show();

                sendReminderMessage();

            } else {

                Toast.makeText(this,
                        "SMS permission denied.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Sends a reminder SMS to the configured phone number.
     */
    private void sendReminderMessage() {

        try {

            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    PHONE_NUMBER,
                    null,
                    MESSAGE,
                    null,
                    null);

            Toast.makeText(this,
                    "Reminder sent successfully.",
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {

            Toast.makeText(this,
                    "Failed to send SMS: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }
}