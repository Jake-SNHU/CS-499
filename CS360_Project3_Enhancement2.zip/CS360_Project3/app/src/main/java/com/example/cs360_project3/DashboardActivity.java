package com.example.cs360_project3;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DashboardActivity extends Activity {

    private static final int SMS_PERMISSION_CODE = 1;

    private DatabaseHelper db;

    private RecyclerView recyclerView;
    private EventAdapter adapter;

    private EditText etName;
    private EditText etDate;
    private EditText etTime;
    private EditText etDesc;
    private EditText etSearch;

    private Spinner spinnerSort;

    private Button btnSave;
    private Button btnSearch;

    // Used to determine whether Save should insert or update
    private int selectedEventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        db = new DatabaseHelper(this);

        initializeViews();
        setupRecyclerView();
        setupSpinner();

        loadEvents("name");

        btnSave.setOnClickListener(v -> saveEvent());

        btnSearch.setOnClickListener(v -> searchEvents());

        spinnerSort.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(android.widget.AdapterView<?> parent,
                                               android.view.View view,
                                               int position,
                                               long id) {

                        switch (position) {

                            case 1:
                                loadEvents("date");
                                break;

                            case 2:
                                loadEvents("time");
                                break;

                            default:
                                loadEvents("name");
                                break;
                        }
                    }

                    @Override
                    public void onNothingSelected(android.widget.AdapterView<?> parent) {

                    }
                });
    }

    /**
     * Connect XML controls.
     */
    private void initializeViews() {

        recyclerView = findViewById(R.id.recyclerEvents);

        etName = findViewById(R.id.etEventName);
        etDate = findViewById(R.id.etEventDate);
        etTime = findViewById(R.id.etEventTime);
        etDesc = findViewById(R.id.etEventDescription);

        etSearch = findViewById(R.id.etSearch);

        spinnerSort = findViewById(R.id.spinnerSort);

        btnSave = findViewById(R.id.btnSaveEvent);
        btnSearch = findViewById(R.id.btnSearch);
    }

    /**
     * Initializes RecyclerView.
     */
    private void setupRecyclerView() {

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new EventAdapter(this, null, db);

        recyclerView.setAdapter(adapter);
    }

    /**
     * Loads sort options.
     */
    private void setupSpinner() {

        String[] options = {
                "Name",
                "Date",
                "Time"
        };

        ArrayAdapter<String> spinnerAdapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_dropdown_item,
                        options);

        spinnerSort.setAdapter(spinnerAdapter);
    }

    /**
     * Loads events using selected sorting method.
     */
    public void loadEvents(String sort) {

        Cursor cursor = db.getAllEvents(sort);

        adapter.swapCursor(cursor);
    }

    /**
     * Searches events by name.
     */
    private void searchEvents() {

        String keyword = etSearch.getText().toString().trim();

        if (keyword.isEmpty()) {

            loadEvents("name");

            return;
        }

        Cursor cursor = db.searchEvents(keyword);

        adapter.swapCursor(cursor);
    }

    /**
     * Inserts or updates an event.
     */
    private void saveEvent() {

        String name = etName.getText().toString().trim();
        String date = etDate.getText().toString().trim();
        String time = etTime.getText().toString().trim();
        String description = etDesc.getText().toString().trim();

        if (name.isEmpty() ||
                date.isEmpty() ||
                time.isEmpty()) {

            Toast.makeText(this,
                    "Please complete all required fields.",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        boolean success;

        if (selectedEventId == -1) {

            success = db.insertEvent(
                    name,
                    date,
                    time,
                    description);

        } else {

            success = db.updateEvent(
                    selectedEventId,
                    name,
                    date,
                    time,
                    description);

            selectedEventId = -1;

            btnSave.setText("Save Event");
        }

        if (success) {

            Toast.makeText(this,
                    "Event saved.",
                    Toast.LENGTH_SHORT).show();

            clearFields();

            loadEvents(getSelectedSort());

            requestSmsPermission();

        } else {

            Toast.makeText(this,
                    "Unable to save event.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Called by EventAdapter when Edit is pressed.
     */
    public void editEvent(int id,
                          String name,
                          String date,
                          String time,
                          String description) {

        selectedEventId = id;

        etName.setText(name);
        etDate.setText(date);
        etTime.setText(time);
        etDesc.setText(description);

        btnSave.setText("Update Event");
    }

    /**
     * Returns currently selected sort option.
     */
    private String getSelectedSort() {

        switch (spinnerSort.getSelectedItemPosition()) {

            case 1:
                return "date";

            case 2:
                return "time";

            default:
                return "name";
        }
    }

    /**
     * Clears the form.
     */
    private void clearFields() {

        etName.setText("");
        etDate.setText("");
        etTime.setText("");
        etDesc.setText("");
    }

    /**
     * Requests SMS permission.
     */
    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.SEND_SMS
                    },
                    SMS_PERMISSION_CODE);
        }
    }
}
