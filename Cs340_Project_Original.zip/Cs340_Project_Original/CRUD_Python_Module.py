# CRUD_Python_Module.py

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self, username='aacuser', password='Jessie', host='localhost', port=27017, db='aac', col='animals'):
        """
        Initialize the MongoDB client and authenticate.
        """
        try:
            self.client = MongoClient(f"mongodb://{username}:{password}@{host}:{port}/")
            self.database = self.client[db]
            self.collection = self.database[col]
        except Exception as e:
            raise Exception(f"Failed to connect to MongoDB: {e}")

    # -----------------------------
    # CREATE
    # -----------------------------
    def create(self, data: dict) -> bool:
        """
        Insert a document into the collection.
        Returns True if document is inserted, else False.
        """
        if data is None or not isinstance(data, dict):
            raise Exception("Invalid data: Must supply a dictionary.")

        try:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        except Exception as e:
            print(f"Error inserting document: {e}")
            return False

    # -----------------------------
    # READ
    # -----------------------------
    def read(self, query: dict) -> list:
        """
        Query for documents using a key/value dictionary.
        Returns a list of results.
        """
        try:
            cursor = self.collection.find(query)
            results = list(cursor)
            return results
        except Exception as e:
            print(f"Error reading documents: {e}")
            return []
    # -----------------------------
    # UPDATE
    # -----------------------------
    def update(self, query: dict, new_values: dict) -> int:
        """
        Update document(s) in the collection.
        """
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            raise Exception("Query and update parameters must be dictionaries.")

        try:
            result = self.collection.update_many(query, new_values)
            return result.modified_count
        except Exception as e:
            print(f"Error updating documents: {e}")
            return 0

    # -----------------------------
    # DELETE
    # -----------------------------
    def delete(self, query: dict) -> int:
        """
        Delete document(s) from the collection.
        """
        if not isinstance(query, dict):
            raise Exception("Query must be a dictionary.")

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"Error deleting documents: {e}")
            return 0
