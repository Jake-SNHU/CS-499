package com.example.cs360_project3;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    private Context context;
    private Cursor cursor;
    private DatabaseHelper db;

    public EventAdapter(Context context, Cursor cursor, DatabaseHelper db) {
        this.context = context;
        this.cursor = cursor;
        this.db = db;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDate;
        Button btnDelete;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvEventName);
            tvDate = view.findViewById(R.id.tvEventDate);
            btnDelete = view.findViewById(R.id.btnDelete);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.event_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (cursor.moveToPosition(position)) {

            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String date = cursor.getString(2);

            holder.tvName.setText(name);
            holder.tvDate.setText(date);

            holder.btnDelete.setOnClickListener(v -> {
                db.deleteEvent(id);
                ((DashboardActivity) context).recreate();
            });
        }
    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }
}