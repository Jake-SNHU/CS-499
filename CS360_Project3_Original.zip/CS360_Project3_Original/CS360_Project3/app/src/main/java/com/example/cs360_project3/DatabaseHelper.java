package com.example.cs360_project3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Handles database creation and CRUD operations.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "eventTracker.db";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Event Table
    private static final String TABLE_EVENTS = "events";
    private static final String COL_EVENT_ID = "eventId";
    private static final String COL_EVENT_NAME = "name";
    private static final String COL_EVENT_DATE = "date";
    private static final String COL_EVENT_TIME = "time";
    private static final String COL_EVENT_DESC = "description";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_EVENTS + " (" +
                COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EVENT_NAME + " TEXT, " +
                COL_EVENT_DATE + " TEXT, " +
                COL_EVENT_TIME + " TEXT, " +
                COL_EVENT_DESC + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // ---------- USER METHODS ----------

    /**
     * Registers a new user after validating the input.
     */
    public boolean registerUser(String username, String password) {

        if (username == null || username.trim().isEmpty()) {
            return false;
        }

        if (password == null || password.length() < 8) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_USERNAME, username.trim());

        values.put(COL_PASSWORD, hashPassword(password));

        return db.insert(TABLE_USERS, null, values) != -1;
    }

    /**
     * Verifies user login credentials.
     */
    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(

                TABLE_USERS,

                null,

                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",

                new String[]{
                        username,
                        hashPassword(password)
                },

                null,

                null,

                null

        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();

        return exists;
    }

    // ---------- EVENT METHODS ----------

    /**
     * Inserts an event into the database.
     */
    public boolean insertEvent(String name,
                               String date,
                               String time,
                               String desc) {

        if (name.trim().isEmpty()
                || date.trim().isEmpty()
                || time.trim().isEmpty()) {

            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_EVENT_NAME, name);

        values.put(COL_EVENT_DATE, date);

        values.put(COL_EVENT_TIME, time);

        values.put(COL_EVENT_DESC, desc);

        return db.insert(TABLE_EVENTS,
                null,
                values) != -1;
    }

    /**
     * Returns all events sorted alphabetically.
     */
    public Cursor getAllEvents() {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(

                TABLE_EVENTS,

                null,

                null,

                null,

                null,

                null,

                COL_EVENT_NAME + " ASC"

        );

    }

    /**
     * Deletes an event from the database.
     */
    public boolean deleteEvent(int id) {

        SQLiteDatabase db = getWritableDatabase();

        int rows = db.delete(

                TABLE_EVENTS,

                COL_EVENT_ID + "=?",

                new String[]{
                        String.valueOf(id)
                }

        );

        return rows > 0;

    }
    /**
     * Encrypts a password using SHA-256.
     *
     * @param password Plain text password.
     * @return Hashed password.
     */
    private String hashPassword(String password) {

        try {

            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            byte[] hash = digest.digest(password.getBytes());

            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {

            throw new RuntimeException("Unable to hash password.");

        }
    }
    /**
     * Searches for events by name.
     */
    public Cursor searchEvents(String keyword) {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(

                TABLE_EVENTS,

                null,

                COL_EVENT_NAME + " LIKE ?",

                new String[]{
                        "%" + keyword + "%"
                },

                null,

                null,

                COL_EVENT_NAME + " ASC"

        );

    }
    /**
     * Updates an existing event.
     */
    public boolean updateEvent(int id,
                               String name,
                               String date,
                               String time,
                               String description) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_EVENT_NAME, name);

        values.put(COL_EVENT_DATE, date);

        values.put(COL_EVENT_TIME, time);

        values.put(COL_EVENT_DESC, description);

        int rows = db.update(

                TABLE_EVENTS,

                values,

                COL_EVENT_ID + "=?",

                new String[]{
                        String.valueOf(id)
                }

        );

        return rows > 0;
    }
}