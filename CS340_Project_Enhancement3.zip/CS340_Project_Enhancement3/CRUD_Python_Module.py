# CRUD_Python_Module.py

from pymongo import MongoClient
from bson.objectid import ObjectId
import logging

# ---------------------------------------
# Configure Logging
# ---------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


class AnimalShelter:
    """
    CRUD operations for the Animal collection in MongoDB.

    Enhanced for CS-499 Category Three:
    - Connection verification
    - Logging
    - Input validation
    - Projection support
    - Sorting support
    - Pagination
    - Search helper methods
    """

    def __init__(
            self,
            username='aacuser',
            password='Jessie',
            host='localhost',
            port=27017,
            db='aac',
            col='animals'
    ):

        try:

            self.client = MongoClient(
                f"mongodb://{username}:{password}@{host}:{port}/",
                serverSelectionTimeoutMS=5000
            )

            # Verify the connection
            self.client.server_info()

            self.database = self.client[db]
            self.collection = self.database[col]

            logging.info("Connected to MongoDB successfully.")

        except Exception as e:

            logging.error(f"Database connection failed: {e}")
            raise

    # --------------------------------------------------------
    # CREATE
    # --------------------------------------------------------

    def create(self, data: dict) -> bool:
        """
        Inserts a new animal document.
        """

        if not isinstance(data, dict):
            raise ValueError("Data must be a dictionary.")

        required = [
            "animal_type",
            "breed",
            "name",
            "age_upon_outcome_in_weeks"
        ]

        for field in required:

            if field not in data:
                raise ValueError(f"Missing required field: {field}")

        try:

            result = self.collection.insert_one(data)

            if result.inserted_id:

                logging.info("Animal inserted successfully.")

                return True

            return False

        except Exception as e:

            logging.error(f"Insert failed: {e}")

            return False

    # --------------------------------------------------------
    # READ
    # --------------------------------------------------------

    def read(
            self,
            query=None,
            projection=None,
            sort_field=None,
            ascending=True,
            page=1,
            page_size=100
    ):
        """
        Reads documents from MongoDB.

        Supports:
        - Projection
        - Sorting
        - Pagination
        """

        try:

            if query is None:
                query = {}

            cursor = self.collection.find(query, projection)

            # Sorting
            if sort_field:

                direction = 1 if ascending else -1

                cursor = cursor.sort(sort_field, direction)

            # Pagination
            skip = (page - 1) * page_size

            cursor = cursor.skip(skip).limit(page_size)

            return list(cursor)

        except Exception as e:

            logging.error(f"Read failed: {e}")

            return []

    # --------------------------------------------------------
    # UPDATE
    # --------------------------------------------------------

    def update(self, query: dict, new_values: dict) -> int:
        """
        Updates one or more documents.
        """

        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")

        if not isinstance(new_values, dict):
            raise ValueError("Update values must be a dictionary.")

        try:

            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )

            logging.info(
                f"{result.modified_count} document(s) updated."
            )

            return result.modified_count

        except Exception as e:

            logging.error(f"Update failed: {e}")

            return 0

    # --------------------------------------------------------
    # DELETE
    # --------------------------------------------------------

    def delete(self, query: dict) -> int:
        """
        Deletes matching documents.
        """

        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")

        try:

            result = self.collection.delete_many(query)

            logging.info(
                f"{result.deleted_count} document(s) deleted."
            )

            return result.deleted_count

        except Exception as e:

            logging.error(f"Delete failed: {e}")

            return 0

    # --------------------------------------------------------
    # SEARCH BY BREED
    # --------------------------------------------------------

    def search_by_breed(self, breed):
        """
        Performs a case-insensitive breed search.
        """

        try:

            return list(

                self.collection.find({

                    "breed": {

                        "$regex": breed,

                        "$options": "i"

                    }

                })

            )

        except Exception as e:

            logging.error(f"Breed search failed: {e}")

            return []

    # --------------------------------------------------------
    # SEARCH BY RESCUE CATEGORY
    # --------------------------------------------------------

    def search_rescue(self, rescue_type):
        """
        Returns dogs appropriate for a rescue category.
        """

        rescue_queries = {

            "Water": {

                "animal_type": "Dog",

                "breed": {

                    "$in": [

                        "Labrador Retriever Mix",
                        "Chesapeake Bay Retriever",
                        "Newfoundland"

                    ]

                }

            },

            "Mountain": {

                "animal_type": "Dog",

                "breed": {

                    "$in": [

                        "German Shepherd",
                        "Alaskan Malamute",
                        "Old English Sheepdog",
                        "Siberian Husky",
                        "Rottweiler"

                    ]

                }

            },

            "Disaster": {

                "animal_type": "Dog",

                "breed": {

                    "$in": [

                        "Doberman Pinscher",
                        "German Shepherd",
                        "Golden Retriever",
                        "Bloodhound",
                        "Rottweiler"

                    ]

                }

            }

        }

        try:

            query = rescue_queries.get(rescue_type, {})

            return list(self.collection.find(query))

        except Exception as e:

            logging.error(f"Rescue search failed: {e}")

            return []

    # --------------------------------------------------------
    # FIND ONE BY OBJECT ID
    # --------------------------------------------------------

    def find_by_id(self, object_id):
        """
        Retrieves one document by ObjectId.
        """

        try:

            return self.collection.find_one({

                "_id": ObjectId(object_id)

            })

        except Exception as e:

            logging.error(f"Find by ID failed: {e}")

            return None

    # --------------------------------------------------------
    # COUNT DOCUMENTS
    # --------------------------------------------------------

    def count(self, query=None):
        """
        Returns the number of matching documents.
        """

        if query is None:
            query = {}

        try:

            return self.collection.count_documents(query)

        except Exception as e:

            logging.error(f"Count failed: {e}")

            return 0