package com.example.cs360_project3;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

/**
 * RecyclerView adapter used to display all saved events.
 * Each row shows the event name, date, and a delete button.
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    private final Context context;
    private Cursor cursor;
    private final DatabaseHelper db;

    /**
     * Constructor.
     *
     * @param context Activity context
     * @param cursor Database cursor containing event records
     * @param db Database helper
     */
    public EventAdapter(Context context, Cursor cursor, DatabaseHelper db) {
        this.context = context;
        this.cursor = cursor;
        this.db = db;
    }

    /**
     * Holds references to each view in an event row.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvName;
        TextView tvDate;
        Button btnDelete;

        public ViewHolder(View view) {
            super(view);

            tvName = view.findViewById(R.id.tvEventName);
            tvDate = view.findViewById(R.id.tvEventDate);
            btnDelete = view.findViewById(R.id.btnDelete);
        }
    }

    /**
     * Creates a new ViewHolder for the RecyclerView.
     */
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.event_item, parent, false);

        return new ViewHolder(view);
    }

    /**
     * Populates each RecyclerView row with database data.
     */
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        if (cursor == null || !cursor.moveToPosition(position)) {
            return;
        }

        int id = cursor.getInt(
                cursor.getColumnIndexOrThrow("eventId"));

        String name = cursor.getString(
                cursor.getColumnIndexOrThrow("name"));

        String date = cursor.getString(
                cursor.getColumnIndexOrThrow("date"));

        holder.tvName.setText(name);
        holder.tvDate.setText(date);

        holder.btnDelete.setOnClickListener(v -> {

            db.deleteEvent(id);

            // Refresh the RecyclerView with updated data
            swapCursor(db.getAllEvents());
        });
    }

    /**
     * Returns the number of events currently displayed.
     */
    @Override
    public int getItemCount() {
        return cursor == null ? 0 : cursor.getCount();
    }

    /**
     * Replaces the current cursor with a new one and refreshes the list.
     *
     * @param newCursor Updated database cursor
     */
    public void swapCursor(Cursor newCursor) {

        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }

        cursor = newCursor;
        notifyDataSetChanged();
    }
}