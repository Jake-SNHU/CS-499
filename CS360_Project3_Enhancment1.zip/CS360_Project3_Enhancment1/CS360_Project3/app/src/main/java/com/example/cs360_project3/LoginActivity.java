package com.example.cs360_project3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Handles user authentication including account creation and login.
 */
public class LoginActivity extends Activity {

    // User interface components
    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnCreateAccount;

    // Database helper
    private DatabaseHelper db;

    /**
     * Initializes the login screen and button listeners.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);

        initializeViews();

        btnLogin.setOnClickListener(v -> loginUser());

        btnCreateAccount.setOnClickListener(v -> registerUser());
    }

    /**
     * Connects all UI components to their XML counterparts.
     */
    private void initializeViews() {

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);
    }

    /**
     * Attempts to authenticate an existing user.
     */
    private void loginUser() {

        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (!validateInput(username, password)) {
            return;
        }

        try {

            if (db.checkUser(username, password)) {

                Toast.makeText(this,
                        "Login successful!",
                        Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(this, DashboardActivity.class);
                startActivity(intent);
                finish();

            } else {

                Toast.makeText(this,
                        "Invalid username or password.",
                        Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {

            Toast.makeText(this,
                    "Login failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Creates a new user account.
     */
    private void registerUser() {

        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (!validateInput(username, password)) {
            return;
        }

        try {

            if (db.registerUser(username, password)) {

                Toast.makeText(this,
                        "Account created successfully.",
                        Toast.LENGTH_SHORT).show();

                clearFields();

            } else {

                Toast.makeText(this,
                        "Username already exists.",
                        Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {

            Toast.makeText(this,
                    "Registration failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Validates username and password before accessing the database.
     *
     * @return true if the input is valid.
     */
    private boolean validateInput(String username, String password) {

        if (username.isEmpty()) {

            etUsername.setError("Username is required.");
            etUsername.requestFocus();
            return false;
        }

        if (password.isEmpty()) {

            etPassword.setError("Password is required.");
            etPassword.requestFocus();
            return false;
        }

        if (password.length() < 8) {

            etPassword.setError("Password must be at least 8 characters.");
            etPassword.requestFocus();
            return false;
        }

        return true;
    }

    /**
     * Clears the username and password fields after successful registration.
     */
    private void clearFields() {

        etUsername.setText("");
        etPassword.setText("");
    }
}