package com.example.cs360_project3;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DashboardActivity extends Activity {

    // Request code for SMS permission
    private static final int SMS_PERMISSION_CODE = 1;

    // Database helper
    private DatabaseHelper db;

    // UI Components
    private RecyclerView recyclerView;
    private EditText etName;
    private EditText etDate;
    private EditText etTime;
    private EditText etDesc;
    private Button btnSave;

    /**
     * Initializes the dashboard screen and loads saved events.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        db = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerEvents);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        etName = findViewById(R.id.etEventName);
        etDate = findViewById(R.id.etEventDate);
        etTime = findViewById(R.id.etEventTime);
        etDesc = findViewById(R.id.etEventDescription);
        btnSave = findViewById(R.id.btnSaveEvent);

        loadEvents();

        btnSave.setOnClickListener(v -> saveEvent());
    }

    /**
     * Validates user input and saves the event to the database.
     */
    private void saveEvent() {

        String name = etName.getText().toString().trim();
        String date = etDate.getText().toString().trim();
        String time = etTime.getText().toString().trim();
        String description = etDesc.getText().toString().trim();

        // Validate required fields
        if (name.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this,
                    "Event name, date, and time are required.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        try {

            boolean inserted = db.insertEvent(name, date, time, description);

            if (inserted) {

                Toast.makeText(this,
                        "Event saved successfully.",
                        Toast.LENGTH_SHORT).show();

                clearFields();
                loadEvents();
                requestSmsPermission();

            } else {

                Toast.makeText(this,
                        "Unable to save event.",
                        Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {

            Toast.makeText(this,
                    "Error: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Reloads all events from the SQLite database into the RecyclerView.
     */
    private void loadEvents() {

        Cursor cursor = db.getAllEvents();
        recyclerView.setAdapter(new EventAdapter(this, cursor, db));
    }

    /**
     * Clears all text fields after an event has been saved.
     */
    private void clearFields() {

        etName.setText("");
        etDate.setText("");
        etTime.setText("");
        etDesc.setText("");
    }

    /**
     * Requests SMS permission if it has not already been granted.
     */
    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }
}
